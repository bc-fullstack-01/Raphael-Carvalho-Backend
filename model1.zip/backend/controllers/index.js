exports.PostController = require('./post-controller.js')
exports.CommentController = require('./comment-controller.js')