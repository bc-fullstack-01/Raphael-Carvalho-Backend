  "dependencies": {
    "-": "^0.0.1",
    "body-parser": "^1.20.0",
    "D": "^1.0.0",
    "express": "^4.18.1"
  },



  package json sem sentido analisar depis